library(tidyverse)
ten <- read_csv(here::here("data", "cz_all_annotated.csv"))

ten %>%
  separate_rows(features, sep = "\\|") %>%
  separate(features, into = c("feature", "value"), sep = "=") %>% 
  filter(feature == "Case") %>%
  count(value)

ten %>%
  separate_rows(features, sep = "\\|") %>%
  separate(features, into = c("feature", "value"), sep = "=") %>% 
  count(index, feature) %>%
  count(feature, n)

case_count <- ten %>%
  separate_rows(features, sep = "\\|") %>%
  separate(features, into = c("feature", "value"), sep = "=") %>% 
  filter(feature == "Case") %>%
  count(value)



ten %>%
  separate_rows(features, sep = "\\|") %>%
  separate(features, into = c("feature", "value"), sep = "=") %>% 
  filter(feature == "Case") %>%
  pull(value) %>%
  janitor::tabyl()

case_count %>%
  pull(n) %>%
  chisq.test(p = c(0.5, 0.1, 0.1, 0.1, 0.1, 0.1))

  

ten %>%
  separate_rows(features, sep = "\\|") %>%
  separate(features, into = c("feature", "value"), sep = "=") %>% 
  filter(feature == "Case") %>%
  ggplot() +
  geom_bar(aes(x = value)) +
  geom_text(data = case_count, aes(x = value, y = n, label = n), vjust = -0.5, colour = "grey20") +
  labs(x = "Падеж", y = "Частота", title = "Распределение падежей местоимения ten") +
  coord_cartesian(ylim = c(0, 700)) +
  theme_bw()

ggsave("dist_case_black_bars.png", scale = 2)

ten %>%
  separate_rows(features, sep = "\\|") %>%
  separate(features, into = c("feature", "value"), sep = "=") %>% 
  filter(feature == "Case") %>%
  ggplot() +
  geom_bar(aes(x = "", fill = value), position = "fill", width = 0.3) +
  labs(x = "", fill = "Падеж", y = "Частота", title = "Распределение падежей местоимения ten") +
  scale_fill_brewer(palette = "Set3") +
  coord_flip() +
  theme_bw()
